import UIKit

struct Result: Codable {
    var name: String
    var age: Int
}

func apiCall() async {
    guard let url = URL(string: "http://localhost:8080") else {
        return
    }
    do {
        let (data, _) = try await URLSession.shared.data(from: url)
        if let decodedResponse = try? JSONDecoder().decode(Result.self, from: data){
            print("Name: \(decodedResponse)")
        }
    }catch{
        print("invalid data")
    }
}
Task{
    await apiCall()
}
//await apiCall()
print("End")


